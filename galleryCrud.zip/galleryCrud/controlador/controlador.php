<?php
  
  include_once 'vista/view.php';
  

?>