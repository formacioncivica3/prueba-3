<?php

  include '../vista/formEdit.php';


?>